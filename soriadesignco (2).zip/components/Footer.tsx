
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FAF9F6] border-t border-[#EADDCA] pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <h2 className="brand-font text-3xl font-light text-[#5C4033] mb-8 uppercase tracking-[0.2em]">Soriadesignco</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12 text-[#5C4033]">
          <div>
            <h4 className="text-xs uppercase tracking-widest font-semibold mb-4 text-[#8B4513]">Sosial Media</h4>
            <a href="https://instagram.com/soriadesignco" target="_blank" rel="noopener noreferrer" className="hover:text-[#A0522D] transition-colors">
              Instagram
            </a>
          </div>
          <div>
            <h4 className="text-xs uppercase tracking-widest font-semibold mb-4 text-[#8B4513]">Əlaqə</h4>
            <a href="https://wa.me/994602377137" className="block hover:text-[#A0522D] transition-colors">+994(60)2377137 (WhatsApp)</a>
            <a href="mailto:soriadesignco@gmail.com" className="block hover:text-[#A0522D] transition-colors mt-2">soriadesignco@gmail.com</a>
          </div>
          <div>
            <h4 className="text-xs uppercase tracking-widest font-semibold mb-4 text-[#8B4513]">Xidmət</h4>
            <p className="text-sm font-light">Bütün Azərbaycan üzrə çatdırılma</p>
          </div>
        </div>
        
        <div className="pt-8 border-t border-[#EADDCA] text-[#A0522D] text-[10px] uppercase tracking-widest">
          &copy; {new Date().getFullYear()} Soriadesignco. Bütün hüquqlar qorunur.
        </div>
      </div>
    </footer>
  );
};

export default Footer;

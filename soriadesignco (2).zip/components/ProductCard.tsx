
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  return (
    <div className="group relative">
      <div className="aspect-[3/4] w-full overflow-hidden rounded-sm bg-[#F5F5DC] relative">
        {product.isNew && (
          <span className="absolute top-4 left-4 bg-[#8B4513] text-white text-[10px] uppercase tracking-widest px-3 py-1 z-10 rounded-full shadow-md">
            Yeni
          </span>
        )}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />
        <button
          onClick={() => onAddToCart(product)}
          className="absolute bottom-4 right-4 bg-white/90 hover:bg-[#8B4513] hover:text-white p-2.5 rounded-full shadow-lg transition-all transform translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </div>
      <div className="mt-4 flex flex-col items-center text-center px-2">
        <h3 className="text-sm font-medium text-[#1A1A1A] tracking-wide uppercase">{product.name}</h3>
        {product.material && <span className="text-[10px] text-[#A0522D] uppercase tracking-wider mb-1">{product.material}</span>}
        <p className="text-md font-semibold text-[#8B4513]">{product.price} AZN</p>
      </div>
    </div>
  );
};

export default ProductCard;

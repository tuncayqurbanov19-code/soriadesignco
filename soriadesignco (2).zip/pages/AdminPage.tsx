
import React, { useState } from 'react';
import { Product, Category } from '../types';

interface AdminPageProps {
  products: Product[];
  addProduct: (p: Product) => void;
  editProduct: (id: string, p: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
}

const AdminPage: React.FC<AdminPageProps> = ({ products, addProduct, editProduct, deleteProduct }) => {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    image: '',
    category: Category.Watches,
    material: '',
    isNew: false
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price || !formData.image) return;

    const newProduct: Product = {
      id: Date.now().toString(),
      name: formData.name,
      price: parseFloat(formData.price),
      image: formData.image,
      category: formData.category,
      material: formData.material || undefined,
      isNew: formData.isNew
    };

    addProduct(newProduct);
    setFormData({ name: '', price: '', image: '', category: Category.Watches, material: '', isNew: false });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-light text-[#5C4033] uppercase tracking-widest mb-12 text-center">Admin Paneli</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Form to Add Product */}
        <div className="bg-white p-8 border border-[#EADDCA] shadow-sm rounded-sm">
          <h2 className="text-lg font-light uppercase tracking-widest mb-6">Yeni Məhsul Əlavə Et</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs uppercase tracking-widest text-[#8B4513] mb-1">Məhsul Adı</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-[#FAF9F6] border border-[#EADDCA] p-3 text-sm focus:outline-none focus:border-[#8B4513]"
                required
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-[#8B4513] mb-1">Qiymət (AZN)</label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="w-full bg-[#FAF9F6] border border-[#EADDCA] p-3 text-sm focus:outline-none focus:border-[#8B4513]"
                required
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-[#8B4513] mb-1">Şəkil Linki (URL)</label>
              <input
                type="text"
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                className="w-full bg-[#FAF9F6] border border-[#EADDCA] p-3 text-sm focus:outline-none focus:border-[#8B4513]"
                required
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-[#8B4513] mb-1">Material (məs. Qızıl, Taxta)</label>
              <input
                type="text"
                value={formData.material}
                onChange={(e) => setFormData({ ...formData, material: e.target.value })}
                className="w-full bg-[#FAF9F6] border border-[#EADDCA] p-3 text-sm focus:outline-none focus:border-[#8B4513]"
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-widest text-[#8B4513] mb-1">Kateqoriya</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as Category })}
                className="w-full bg-[#FAF9F6] border border-[#EADDCA] p-3 text-sm focus:outline-none focus:border-[#8B4513]"
              >
                {Object.values(Category).map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center py-2">
              <input 
                type="checkbox" 
                id="isNew"
                checked={formData.isNew}
                onChange={(e) => setFormData({ ...formData, isNew: e.target.checked })}
                className="accent-[#8B4513] h-4 w-4"
              />
              <label htmlFor="isNew" className="ml-2 text-xs uppercase tracking-widest text-[#8B4513]">Yeni Gələndir?</label>
            </div>
            <button
              type="submit"
              className="w-full bg-[#5C4033] text-white py-3 uppercase tracking-widest text-xs hover:bg-[#8B4513] transition-colors pt-4"
            >
              Əlavə Et
            </button>
          </form>
        </div>

        {/* Product List for Management */}
        <div className="lg:col-span-2 space-y-4 overflow-y-auto max-h-[70vh] pr-4">
          <h2 className="text-lg font-light uppercase tracking-widest mb-6">Məhsul Siyahısı</h2>
          {products.map((p) => (
            <div key={p.id} className="flex items-center justify-between bg-white p-4 border border-[#EADDCA] rounded-sm group">
              <div className="flex items-center space-x-4">
                <img src={p.image} alt={p.name} className="w-12 h-12 object-cover rounded-sm" />
                <div>
                  <h3 className="text-sm font-medium">{p.name}</h3>
                  <p className="text-xs text-[#8B4513]">
                    {p.price} AZN | {p.category} {p.material && `| ${p.material}`} {p.isNew && '| Yeni'}
                  </p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => deleteProduct(p.id)}
                  className="text-red-400 hover:text-red-600 p-2"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminPage;

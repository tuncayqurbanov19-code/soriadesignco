
import React from 'react';
import { Link } from 'react-router-dom';
import { CartItem } from '../types';

interface CartPageProps {
  cart: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeFromCart: (id: string) => void;
}

const CartPage: React.FC<CartPageProps> = ({ cart, updateQuantity, removeFromCart }) => {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-32 text-center">
        <h2 className="text-3xl font-light text-[#5C4033] mb-8 uppercase tracking-widest">Səbət Boşdur</h2>
        <Link to="/" className="inline-block border border-[#8B4513] text-[#8B4513] px-10 py-3 uppercase tracking-widest text-sm hover:bg-[#8B4513] hover:text-white transition-all">
          Alış-verişə davam et
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-light text-[#5C4033] uppercase tracking-widest mb-12 text-center">Səbətiniz</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-6">
          {cart.map((item) => (
            <div key={item.id} className="flex items-center space-x-6 bg-white p-4 rounded-sm shadow-sm border border-[#EADDCA]/50">
              <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-sm" />
              <div className="flex-grow">
                <h3 className="text-sm font-medium uppercase tracking-wide">{item.name}</h3>
                <p className="text-[#8B4513] mt-1">{item.price} AZN</p>
                <div className="flex items-center space-x-4 mt-4">
                  <div className="flex items-center border border-[#EADDCA] rounded-sm">
                    <button onClick={() => updateQuantity(item.id, -1)} className="px-3 py-1 text-[#8B4513] hover:bg-[#F5F5DC]">-</button>
                    <span className="px-4 py-1 border-x border-[#EADDCA] text-sm">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="px-3 py-1 text-[#8B4513] hover:bg-[#F5F5DC]">+</button>
                  </div>
                  <button onClick={() => removeFromCart(item.id)} className="text-[10px] uppercase text-red-400 tracking-widest hover:text-red-600">Sil</button>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-[#5C4033]">{item.price * item.quantity} AZN</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#F5F5DC]/50 p-8 h-fit border border-[#EADDCA]">
          <h2 className="text-lg font-light uppercase tracking-widest mb-6 border-b border-[#EADDCA] pb-4">Cəmi</h2>
          <div className="space-y-4 text-sm tracking-wide">
            <div className="flex justify-between">
              <span>Məbləğ</span>
              <span>{total} AZN</span>
            </div>
            <div className="flex justify-between">
              <span>Çatdırılma</span>
              <span className="text-[#8B4513]">Pulsuz</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t border-[#EADDCA] pt-4">
              <span>Ümumi</span>
              <span>{total} AZN</span>
            </div>
          </div>
          <button className="w-full mt-8 bg-[#5C4033] text-white py-4 uppercase tracking-widest text-xs hover:bg-[#8B4513] transition-colors">
            Ödənişə keç
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartPage;

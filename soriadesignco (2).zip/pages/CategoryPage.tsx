
import React, { useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { Product, Category } from '../types';
import ProductCard from '../components/ProductCard';

interface CategoryPageProps {
  products: Product[];
  addToCart: (p: Product) => void;
}

const CategoryPage: React.FC<CategoryPageProps> = ({ products, addToCart }) => {
  const { category } = useParams<{ category: string }>();
  const [maxPrice, setMaxPrice] = useState<number>(500);
  const [selectedMaterial, setSelectedMaterial] = useState<string>('All');
  const [showOnlyNew, setShowOnlyNew] = useState<boolean>(false);

  const materials = useMemo(() => {
    const categoryProducts = products.filter(p => p.category === category);
    const m = new Set(categoryProducts.map(p => p.material).filter(Boolean));
    return ['All', ...Array.from(m)];
  }, [products, category]);

  const filteredProducts = products.filter(p => {
    const matchesCategory = p.category === category;
    const matchesPrice = p.price <= maxPrice;
    const matchesMaterial = selectedMaterial === 'All' || p.material === selectedMaterial;
    const matchesNew = !showOnlyNew || p.isNew;
    return matchesCategory && matchesPrice && matchesMaterial && matchesNew;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[60vh]">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-light text-black uppercase tracking-[0.3em] mb-4">{category}</h1>
        <p className="text-[#8B4513] font-light tracking-wide">Premium {category?.toLowerCase()} kolleksiyamız</p>
        <div className="mt-8 h-px w-32 bg-[#EADDCA] mx-auto"></div>
      </div>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-64 shrink-0 space-y-10">
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-[#5C4033] mb-6">Qiymət aralığı</h4>
            <input 
              type="range" 
              min="0" 
              max="500" 
              step="10"
              value={maxPrice}
              onChange={(e) => setMaxPrice(parseInt(e.target.value))}
              className="w-full accent-[#8B4513]"
            />
            <div className="flex justify-between mt-2 text-xs text-[#8B4513] font-medium">
              <span>0 AZN</span>
              <span>{maxPrice} AZN</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-[#5C4033] mb-6">Material</h4>
            <div className="space-y-3">
              {materials.map(m => (
                <label key={m as string} className="flex items-center group cursor-pointer">
                  <input 
                    type="radio" 
                    name="material"
                    checked={selectedMaterial === m}
                    onChange={() => setSelectedMaterial(m as string)}
                    className="hidden"
                  />
                  <span className={`w-3 h-3 rounded-full border border-[#8B4513] mr-3 transition-colors ${selectedMaterial === m ? 'bg-[#8B4513]' : 'bg-transparent'}`}></span>
                  <span className={`text-sm tracking-wide ${selectedMaterial === m ? 'text-[#8B4513] font-medium' : 'text-[#5C4033] font-light'}`}>
                    {m === 'All' ? 'Bütün materiallar' : m}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-[#5C4033] mb-6">Xüsusiyyət</h4>
            <label className="flex items-center cursor-pointer group">
              <input 
                type="checkbox" 
                checked={showOnlyNew}
                onChange={() => setShowOnlyNew(!showOnlyNew)}
                className="hidden"
              />
              <span className={`w-4 h-4 rounded-sm border border-[#8B4513] mr-3 flex items-center justify-center transition-colors ${showOnlyNew ? 'bg-[#8B4513]' : 'bg-transparent'}`}>
                {showOnlyNew && (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </span>
              <span className={`text-sm tracking-wide ${showOnlyNew ? 'text-[#8B4513] font-medium' : 'text-[#5C4033] font-light'}`}>
                Yalnız yeni gələnlər
              </span>
            </label>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-grow">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-12">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} onAddToCart={addToCart} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 text-[#A0522D] font-light tracking-widest border border-[#EADDCA] rounded-sm bg-white/30">
              Seçilmiş filtrlərə uyğun məhsul tapılmadı.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;


import React from 'react';
import { useLocation } from 'react-router-dom';
import { Product } from '../types';
import ProductCard from '../components/ProductCard';

interface HomeProps {
  products: Product[];
  addToCart: (p: Product) => void;
}

const Home: React.FC<HomeProps> = ({ products, addToCart }) => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search')?.toLowerCase() || '';

  const filteredProducts = searchQuery
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery) || 
        p.category.toLowerCase().includes(searchQuery) ||
        p.material?.toLowerCase().includes(searchQuery)
      )
    : products;

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section - Hide if searching */}
      {!searchQuery && (
        <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2000&auto=format&fit=crop" 
            alt="Hero"
            className="absolute inset-0 w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-[#F5F5DC]/40"></div>
          <div className="relative text-center px-4 max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-light text-[#5C4033] mb-6 leading-tight">Zəriflik və <br/> Minimalizm</h1>
            <p className="text-[#8B4513] text-lg md:text-xl font-light tracking-wide mb-8">Eviniz və üslubunuz üçün estetik detallar</p>
            <a href="#products" className="inline-block border border-[#8B4513] text-[#8B4513] px-10 py-3 uppercase tracking-widest text-sm hover:bg-[#8B4513] hover:text-white transition-all duration-300">
              Kolleksiyaya Bax
            </a>
          </div>
        </section>
      )}

      {/* Search Header */}
      {searchQuery && (
        <div className="max-w-7xl mx-auto px-4 pt-12 text-center">
          <h2 className="text-2xl font-light text-[#5C4033] uppercase tracking-widest">
            Axtarış nəticələri: "{searchQuery}"
          </h2>
          <p className="text-[#8B4513] mt-2 font-light">{filteredProducts.length} məhsul tapıldı</p>
        </div>
      )}

      {/* Featured Products */}
      <section id="products" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {!searchQuery && (
          <div className="text-center mb-12">
            <h2 className="text-3xl font-light text-[#5C4033] uppercase tracking-[0.2em] mb-4">Ön Çıxanlar</h2>
            <div className="h-px w-24 bg-[#EADDCA] mx-auto"></div>
          </div>
        )}
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-12">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} onAddToCart={addToCart} />
          ))}
        </div>

        {searchQuery && filteredProducts.length === 0 && (
          <div className="text-center py-20 text-[#A0522D] font-light">
            Təəssüf ki, axtarışınıza uyğun məhsul tapılmadı.
          </div>
        )}
      </section>

      {!searchQuery && (
        <section className="bg-[#EADDCA]/20 py-20">
          <div className="max-w-7xl mx-auto px-4 text-center">
              <p className="italic text-[#8B4513] font-light text-xl mb-4">"Sakitlik estetikadan başlayır"</p>
              <p className="text-sm tracking-widest uppercase text-[#A0522D]">Soriadesignco Premium Kolleksiyası</p>
          </div>
        </section>
      )}
    </div>
  );
};

export default Home;

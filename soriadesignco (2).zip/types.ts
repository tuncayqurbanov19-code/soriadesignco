
export enum Category {
  Watches = 'Saatlar',
  Jewelry = 'Bijuteriya',
  Posters = 'Posterlər',
  Accessories = 'Qadın aksesuarları'
}

export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: Category;
  material?: string;
  isNew?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}
